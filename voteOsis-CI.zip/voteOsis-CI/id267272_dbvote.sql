-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 07, 2017 at 12:23 PM
-- Server version: 10.1.20-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id267272_dbabsen`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `nis` int(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `status_vote` varchar(13) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`nis`, `username`, `nama_lengkap`, `kelas`, `jurusan`, `status_vote`) VALUES
(1, 'jovvi', 'Joviandro nopier marbun', '12', 'RPL', '0'),
(2, 'Yiek', 'Yiek alfian', '12', 'RPL', '0'),
(3, 'Fahrizal', 'Fahrizal Syaripdin', '12', 'RPL', '0'),
(4, 'aqsa', 'Muhammad Aqsyal', '12', 'RPL', '0'),
(5, 'Aldin', 'Aldin abb', '12', 'RPL', '0'),
(7, 'test1', 'test1', '12', 'rpl', '0'),
(8, 'Fadla', 'Fadlawalad dimas Zo Charli siregar', '12', 'RPL', '0'),
(9, 'Kevin', 'Kevin Hendra Wijaya', '12', 'RPL', '0'),
(10, 'test2', 'test2', '12', 'RPL', '0'),
(11, 'test3', 'test3', '12', 'RPL', '0'),
(12, 'test4', 'test4', '12', 'RPL', '0'),
(13, 'test5', 'test5', '12', 'RPL', '0');

-- --------------------------------------------------------

--
-- Table structure for table `log_vote`
--

CREATE TABLE `log_vote` (
  `user` text NOT NULL,
  `tanggal_waktu` varchar(255) NOT NULL,
  `add_log` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `calon` varchar(33) NOT NULL,
  `jumlah_vote` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`calon`, `jumlah_vote`) VALUES
('ketua1', 0),
('ketua2', 0),
('ketua3', 0),
('wakil1', 0),
('wakil2', 0),
('wakil3', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`calon`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
