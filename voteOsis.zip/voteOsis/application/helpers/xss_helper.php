<?php

  function andro($str){

    echo htmlentities($str, ENT_QUOTES, 'UTF-8');
  }
