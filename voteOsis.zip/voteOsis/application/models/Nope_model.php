<?php 
class Nope_model extends CI_Model{
	function ddf(){
	$this->db->where('status_vote',0);
	return $this->db->get('akun');
	}
}