<?php 
class Nope extends CI_Controller{
	function index(){
		$this->load->model('nope_model');
		$data['query']=$this->nope_model->ddf()->result();
		$data['total'] = $this->nope_model->ddf()->num_rows();
		$this->load->view('test/test',$data);
		
	}
}
