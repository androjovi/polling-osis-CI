

<div id="columnchart_material" style="width: 100%; height: 100%;"></div>
