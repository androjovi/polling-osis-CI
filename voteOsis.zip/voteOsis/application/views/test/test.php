<h3><?php echo $total; ?></h3>
<table border='1'>
<thead>
<tr>
<td>NIS</td>
<td>Nama</td>
<td>Kelas</td>
<td>Jurusan</td>

</tr>
</thead>
<tbody>
<?php foreach($query as $k): ?>
<tr>

<td><?php echo $k->nis; ?></td>
<td><?php echo $k->nama_lengkap; ?></td>
<td><?php echo $k->kelas; ?></td>
<td><?php echo $k->jurusan; ?></td>

</tr>
<?php endforeach; ?>
</tbody>