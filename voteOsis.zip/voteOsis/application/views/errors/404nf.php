<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="5;url=<?php echo base_url('login'); ?>">
    <title>1x000003</title>
  </head>
  <style>
  body{
    background-color: black;
    width: auto;
    text-align: center;
    color: aqua;
    font-family: monospace;
    font-size: 20px;
  }
  </style>
  <body>
  <p>Halaman ini benar benar ada ?</p>
  <p>Anggap saja halaman ini tidak ada. </p>
  <p>Apa saya menyembunyikan sesuatu ?</p>
  <p>Entahlah!</p>
  <br><br><br><br><br><br>
  <p>Halaman ini benar benar tidak ada!</p>
  <p>Halaman ini tidak pernah dikunjungi!!</p>
  <p>Kamu tidak pernah mengunjungi halaman ini!!</p>
  </body>
</html>
